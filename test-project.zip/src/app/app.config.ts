export const appConfig =  {
    baseUrl: 'https://api.github.com/',
    apiKey: '',
    username : 'coderonfleek',
    token : '57e96b52af0fc4847a6ed9e04ef10832f84be434'
};
